package com.BudgetBuddies.budget_buddies;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
